Resultado:

![alt](result.png)



Paso 1:

![alt](step1.png)

Paso 2:

![alt](step2.png)

Paso 3:

![alt](step3.png)

Paso 4:

![alt](step4.png)

Paso 5:

![alt](step5.png)

Paso 6:

![alt](step6.png)
