//
//  Item.swift
//  WatchPizza
//
//  Created by Jeisson on 11/8/15.
//  Copyright © 2015 WiseWare SAS. All rights reserved.
//

import WatchKit

class Item: NSObject {

    @IBOutlet var titleMix: WKInterfaceLabel!
    var isSelect:Bool = false
}
